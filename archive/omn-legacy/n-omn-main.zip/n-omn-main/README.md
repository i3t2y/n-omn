---
title: omn
emoji: 📊
colorFrom: purple
colorTo: red
sdk: docker
app_port: 7860
pinned: false
license: mit
---
